package com.vamsoft.model;

public class Execution {

	public static void main(String[] args) {
		System.out.println("hii");

	}

}
